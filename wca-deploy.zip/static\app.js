const state = {
  imageData: null,
  stream: null,
  clothes: [],
  currentTemp: 18,
  user: null,
  lastBackPress: 0,
  regionResults: [],
  passwordPurpose: null,
};

const $ = (id) => document.getElementById(id);

function normalizeRegionName(name) {
  const parts = String(name || "").split(/\s+/).filter(Boolean);
  const normalized = [];
  parts.forEach((part) => {
    if (!normalized.includes(part)) {
      normalized.push(part);
    }
  });
  if (normalized.length >= 3 && normalized.at(-1) === normalized.at(-2)) {
    normalized.pop();
  }
  return normalized.join(" ");
}

function setMessage(text, isError = false) {
  const message = $("formMessage");
  message.textContent = text || "";
  message.style.color = isError ? "#b13a2f" : "";
}

async function api(path, options = {}) {
  const response = await fetch(path, {
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
    ...options,
  });
  const data = await response.json();
  if (!response.ok) {
    if (response.status === 401) {
      showAuth();
    }
    throw new Error(data.error || "요청에 실패했습니다.");
  }
  return data;
}

function setAuthMessage(text, isError = false) {
  const message = $("authMessage");
  message.textContent = text || "";
  message.style.color = isError ? "#b13a2f" : "";
}

function showAuth() {
  state.user = null;
  $("authView").hidden = false;
  $("appView").hidden = true;
  closeMenu();
  closeRegionModal();
  $("menuButton").hidden = true;
  $("userBadge").hidden = true;
  $("logoutButton").hidden = true;
  $("refreshButton").hidden = true;
  $("metricUser").textContent = "-";
  $("metricClothes").textContent = "0개";
  $("metricWeather").textContent = "조회 중";
  $("metricHistory").textContent = "0개";
}

function showApp(user) {
  state.user = user;
  $("authView").hidden = true;
  $("appView").hidden = false;
  $("userBadge").textContent = `${user.display_name || user.username} 계정`;
  $("metricUser").textContent = user.display_name || user.username;
  if (user.weather_location) {
    $("metricWeather").textContent = `${normalizeRegionName(user.weather_location)} · 조회 중`;
  }
  $("menuButton").hidden = false;
  $("userBadge").hidden = false;
  $("logoutButton").hidden = false;
  $("refreshButton").hidden = false;
}

async function enterApp(user) {
  showApp(user);
  showAppPage("recommend");
  await refreshAll();
  if (!user.weather_location) {
    openRegionModal();
    return;
  }
  await fetchWeather();
  await getRecommendations();
}

async function checkSession() {
  const data = await api("/api/auth/me");
  if (data.user) {
    await enterApp(data.user);
  } else {
    showAuth();
  }
}

function openRegionModal() {
  closeMenu();
  $("regionModal").hidden = false;
  $("regionSearchInput").focus();
}

function closeRegionModal() {
  $("regionModal").hidden = true;
}

function setRegionMessage(text, isError = false) {
  $("regionMessage").textContent = text || "";
  $("regionMessage").style.color = isError ? "#b13a2f" : "";
}

async function searchRegions() {
  const q = $("regionSearchInput").value.trim();
  if (q.length < 2) {
    setRegionMessage("지역명을 두 글자 이상 입력하세요.", true);
    return;
  }
  setRegionMessage("지역 검색 중입니다.");
  const data = await api(`/api/regions?q=${encodeURIComponent(q)}`);
  state.regionResults = data.items || [];
  if (!state.regionResults.length) {
    $("regionResults").innerHTML = "";
    setRegionMessage("검색 결과가 없습니다. 시/군/구 이름으로 다시 입력해 보세요.", true);
    return;
  }
  $("regionResults").innerHTML = state.regionResults
    .map(
      (item, index) => `
        <button type="button" data-region-index="${index}">
          <strong>${escapeHtml(item.name)}</strong>
        </button>
      `,
    )
    .join("");
  setRegionMessage("사용할 지역을 선택하세요.");
}

async function saveRegion(index) {
  const region = state.regionResults[index];
  if (!region) {
    return;
  }
  setRegionMessage("지역을 저장하는 중입니다.");
  const data = await api("/api/settings/region", {
    method: "POST",
    body: JSON.stringify({
      weather_location: normalizeRegionName(region.name),
      weather_lat: region.lat,
      weather_lon: region.lon,
    }),
  });
  state.user = data.user;
  showApp(data.user);
  closeRegionModal();
  await fetchWeather();
  await getRecommendations();
}

async function login(event) {
  event.preventDefault();
  setAuthMessage("로그인 중입니다.");
  try {
    const data = await api("/api/auth/login", {
      method: "POST",
      body: JSON.stringify({
        username: $("loginUsername").value.trim(),
        password: $("loginPassword").value,
      }),
    });
    $("loginPassword").value = "";
    setAuthMessage("");
    await enterApp(data.user);
  } catch (error) {
    setAuthMessage(error.message, true);
  }
}

async function register(event) {
  event.preventDefault();
  setAuthMessage("계정을 만드는 중입니다.");
  try {
    const data = await api("/api/auth/register", {
      method: "POST",
      body: JSON.stringify({
        username: $("registerUsername").value.trim(),
        email: $("registerEmail").value.trim(),
        display_name: $("registerDisplayName").value.trim(),
        password: $("registerPassword").value,
      }),
    });
    $("registerPassword").value = "";
    setAuthMessage("");
    await enterApp(data.user);
  } catch (error) {
    setAuthMessage(error.message, true);
  }
}

async function logout() {
  await api("/api/auth/logout", { method: "POST", body: "{}" });
  resetForm();
  state.clothes = [];
  renderClothes();
  renderHistory([]);
  $("recommendations").innerHTML = "";
  $("recommendationSummary").innerHTML = "";
  showAppPage("recommend");
  showAuth();
}

function showAppPage(page) {
  document.querySelectorAll(".app-page").forEach((section) => {
    section.hidden = section.dataset.page !== page;
  });
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function openPasswordModal(purpose) {
  closeMenu();
  state.passwordPurpose = purpose;
  $("passwordConfirmInput").value = "";
  $("passwordMessage").textContent = "";
  if (purpose === "closet") {
    $("passwordModalTitle").textContent = "내 옷장 잠금 해제";
    $("passwordModalText").textContent = "내 옷장에 들어가려면 비밀번호를 입력하세요.";
    $("passwordSubmitButton").textContent = "내 옷장 보기";
  }
  if (purpose === "clear") {
    $("passwordModalTitle").textContent = "옷장 초기화";
    $("passwordModalText").textContent = "저장된 옷과 착용 이력이 모두 삭제됩니다. 계속하려면 비밀번호를 입력하세요.";
    $("passwordSubmitButton").textContent = "초기화";
  }
  $("passwordModal").hidden = false;
  $("passwordConfirmInput").focus();
}

function closePasswordModal() {
  $("passwordModal").hidden = true;
  state.passwordPurpose = null;
}

function setPasswordMessage(text, isError = false) {
  $("passwordMessage").textContent = text || "";
  $("passwordMessage").style.color = isError ? "#b13a2f" : "";
}

function openChangePasswordModal() {
  closeMenu();
  $("currentPasswordInput").value = "";
  $("newPasswordInput").value = "";
  $("changePasswordMessage").textContent = "";
  $("changePasswordModal").hidden = false;
  $("currentPasswordInput").focus();
}

function closeChangePasswordModal() {
  $("changePasswordModal").hidden = true;
}

function openResetPasswordModal() {
  $("resetUsernameInput").value = $("loginUsername").value.trim();
  $("resetEmailInput").value = "";
  $("resetCodeInput").value = "";
  $("resetNewPasswordInput").value = "";
  $("resetPasswordMessage").textContent = "";
  $("resetPasswordModal").hidden = false;
  $("resetUsernameInput").focus();
}

function closeResetPasswordModal() {
  $("resetPasswordModal").hidden = true;
}

async function changePassword(event) {
  event.preventDefault();
  try {
    await api("/api/auth/change-password", {
      method: "POST",
      body: JSON.stringify({
        current_password: $("currentPasswordInput").value,
        new_password: $("newPasswordInput").value,
      }),
    });
    $("changePasswordMessage").textContent = "비밀번호를 변경했습니다.";
    $("currentPasswordInput").value = "";
    $("newPasswordInput").value = "";
  } catch (error) {
    $("changePasswordMessage").textContent = error.message;
    $("changePasswordMessage").style.color = "#b13a2f";
  }
}

async function requestResetCode() {
  try {
    await api("/api/auth/request-password-reset", {
      method: "POST",
      body: JSON.stringify({
        username: $("resetUsernameInput").value.trim(),
        email: $("resetEmailInput").value.trim(),
      }),
    });
    $("resetPasswordMessage").style.color = "";
    $("resetPasswordMessage").textContent = "이메일로 인증코드를 보냈습니다. 10분 안에 입력하세요.";
  } catch (error) {
    $("resetPasswordMessage").textContent = error.message;
    $("resetPasswordMessage").style.color = "#b13a2f";
  }
}

async function resetPassword(event) {
  event.preventDefault();
  try {
    await api("/api/auth/reset-password", {
      method: "POST",
      body: JSON.stringify({
        username: $("resetUsernameInput").value.trim(),
        email: $("resetEmailInput").value.trim(),
        code: $("resetCodeInput").value,
        new_password: $("resetNewPasswordInput").value,
      }),
    });
    $("resetPasswordMessage").style.color = "";
    $("resetPasswordMessage").textContent = "비밀번호를 재설정했습니다. 새 비밀번호로 로그인하세요.";
    $("resetCodeInput").value = "";
    $("resetNewPasswordInput").value = "";
  } catch (error) {
    $("resetPasswordMessage").textContent = error.message;
    $("resetPasswordMessage").style.color = "#b13a2f";
  }
}

async function submitPassword(event) {
  event.preventDefault();
  const password = $("passwordConfirmInput").value;
  if (!password) {
    setPasswordMessage("비밀번호를 입력하세요.", true);
    return;
  }
  try {
    if (state.passwordPurpose === "closet") {
      await api("/api/auth/verify-password", {
        method: "POST",
        body: JSON.stringify({ password }),
      });
      closePasswordModal();
      showAppPage("closet");
      return;
    }
    if (state.passwordPurpose === "clear") {
      const result = await api("/api/closet/clear", {
        method: "POST",
        body: JSON.stringify({ password }),
      });
      closePasswordModal();
      await refreshAll();
      await getRecommendations();
      showAppPage("closet");
      alert(`${result.deleted_count || 0}개의 옷을 삭제했습니다.`);
    }
  } catch (error) {
    setPasswordMessage(error.message, true);
  }
}

function openMenu() {
  if (!state.user) {
    return;
  }
  $("menuOverlay").hidden = false;
  $("sideMenu").hidden = false;
  document.body.classList.add("menu-open");
}

function closeMenu() {
  $("menuOverlay").hidden = true;
  $("sideMenu").hidden = true;
  document.body.classList.remove("menu-open");
}

function showBackToast() {
  $("backToast").hidden = false;
  window.clearTimeout(state.backToastTimer);
  state.backToastTimer = window.setTimeout(() => {
    $("backToast").hidden = true;
  }, 1600);
}

function setupBackGuard() {
  if (history.state?.wcaGuard) {
    return;
  }
  history.replaceState({ wcaBase: true }, "");
  history.pushState({ wcaGuard: true }, "");
}

function handleBackButton() {
  if (!$("sideMenu").hidden) {
    closeMenu();
    history.pushState({ wcaGuard: true }, "");
    return;
  }
  const now = Date.now();
  if (now - state.lastBackPress < 1800) {
    window.removeEventListener("popstate", handleBackButton);
    history.back();
    return;
  }
  state.lastBackPress = now;
  showBackToast();
  history.pushState({ wcaGuard: true }, "");
}

async function handleMenuTarget(target) {
  if (target === "closet") {
    openPasswordModal("closet");
    return;
  }
  if (target === "history") {
    showAppPage("history");
  }
  if (target === "recommend") {
    showAppPage("recommend");
  }
  if (target === "region") {
    openRegionModal();
    return;
  }
  if (target === "password") {
    openChangePasswordModal();
    return;
  }
  if (target === "refresh") {
    await refreshAll();
    await fetchWeather();
    await getRecommendations();
  }
  if (target === "logout") {
    await logout();
    return;
  }
  closeMenu();
}

function showPhotoPreview(imageData) {
  state.imageData = imageData;
  $("preview").src = state.imageData;
  $("preview").hidden = false;
  $("photoActions").hidden = false;
  $("cameraActionButton").hidden = true;
}

function showExtraInfoPrompt() {
  $("extraInfoPrompt").hidden = false;
  $("clothForm").hidden = true;
}

function showExtraInfoForm(isUserOverride = true) {
  $("extraInfoPrompt").hidden = true;
  $("clothForm").hidden = false;
  $("userOverride").value = isUserOverride ? "1" : "0";
}

function clearPhoto() {
  state.imageData = null;
  $("mobilePhotoInput").value = "";
  $("preview").hidden = true;
  $("preview").removeAttribute("src");
  $("photoActions").hidden = true;
  $("cameraActionButton").hidden = false;
  $("extraInfoPrompt").hidden = true;
  if (!$("clothId").value) {
    $("clothForm").hidden = true;
  }
  $("cameraState").textContent = "카메라 대기";
}

function payloadFromForm() {
  return {
    image_data: state.imageData,
    auto_tag: $("autoTag").checked,
    name: $("name").value.trim(),
    category: $("category").value,
    sub_category: $("subCategory").value.trim(),
    color: $("color").value.trim(),
    material: $("material").value.trim(),
    warmth: $("warmth").value,
    status: $("status").value,
    notes: $("notes").value.trim(),
    user_override: $("userOverride").value === "1",
  };
}

function resetForm() {
  $("clothId").value = "";
  $("clothForm").reset();
  $("category").value = "상의";
  $("status").value = "착용가능";
  $("userOverride").value = "0";
  $("autoTag").checked = true;
  clearPhoto();
  $("saveButton").textContent = "저장";
  setMessage("");
}

async function startCamera() {
  if (state.stream) {
    return true;
  }
  if (!navigator.mediaDevices?.getUserMedia) {
    $("mobilePhotoInput").click();
    return false;
  }
  try {
    state.stream = await navigator.mediaDevices.getUserMedia({
      video: { facingMode: "environment" },
      audio: false,
    });
    $("video").srcObject = state.stream;
    $("cameraState").textContent = "카메라 사용 중. 카메라 버튼을 한 번 더 누르면 촬영됩니다.";
    return true;
  } catch (error) {
    $("cameraState").textContent = "카메라 접근 실패";
    setMessage("카메라 앱을 열어 사진을 선택합니다.", false);
    $("mobilePhotoInput").click();
    return false;
  }
}

function shouldUseDeviceCamera() {
  return (
    window.matchMedia("(max-width: 760px)").matches ||
    /Android|iPhone|iPad|iPod/i.test(navigator.userAgent) ||
    (!window.isSecureContext && location.hostname !== "127.0.0.1" && location.hostname !== "localhost")
  );
}

async function handleCameraAction() {
  if (shouldUseDeviceCamera()) {
    $("mobilePhotoInput").click();
    return;
  }
  if (state.stream) {
    capturePhoto();
    return;
  }
  await startCamera();
}

function loadPhotoFile(file) {
  if (!file) {
    return;
  }
  const reader = new FileReader();
  reader.onload = () => {
    showPhotoPreview(reader.result);
    $("cameraState").textContent = "사진 선택 완료";
    setMessage("사진이 준비되었습니다. 사용하기를 누르면 자동으로 분석합니다.");
  };
  reader.onerror = () => {
    setMessage("사진을 불러오지 못했습니다.", true);
  };
  reader.readAsDataURL(file);
}

function capturePhoto() {
  const video = $("video");
  if (!video.videoWidth) {
    setMessage("카메라를 먼저 켜주세요.", true);
    return;
  }
  const canvas = $("canvas");
  canvas.width = video.videoWidth;
  canvas.height = video.videoHeight;
  canvas.getContext("2d").drawImage(video, 0, 0);
  showPhotoPreview(canvas.toDataURL("image/png"));
  setMessage("사진이 준비되었습니다. 사용하기를 누르면 자동으로 분석합니다.");
}

function applyTags(tags = {}) {
  if (tags.name) $("name").value = tags.name;
  if (tags.category) $("category").value = tags.category;
  if (tags.sub_category) $("subCategory").value = tags.sub_category;
  if (tags.color) $("color").value = tags.color;
  if (tags.material) $("material").value = tags.material;
  if (tags.warmth) $("warmth").value = tags.warmth;
  if (tags.notes) $("notes").value = tags.notes;
}

async function analyzePhoto() {
  if (!state.imageData) {
    setMessage("먼저 옷 사진을 촬영하세요.", true);
    return;
  }
  setMessage("AI가 옷을 분석하는 중입니다.");
  $("usePhotoButton").disabled = true;
  try {
    const data = await api("/api/analyze-clothing", {
      method: "POST",
      body: JSON.stringify({ image_data: state.imageData }),
    });
    applyTags(data.tags || {});
    if (data.tags?.notes?.includes("OPENAI_API_KEY")) {
      setMessage(data.tags.notes, true);
    } else {
      setMessage("AI 분석 결과를 입력칸에 채웠습니다. 확인 후 저장하세요.");
    }
    showExtraInfoPrompt();
  } catch (error) {
    setMessage(error.message, true);
  } finally {
    $("usePhotoButton").disabled = false;
  }
}

async function usePhoto() {
  if (!state.imageData) {
    setMessage("먼저 옷 사진을 촬영하세요.", true);
    return;
  }
  await analyzePhoto();
}

function fillForm(item) {
  $("clothId").value = item.cloth_id;
  $("name").value = item.name || "";
  $("category").value = item.category || "기타";
  $("subCategory").value = item.sub_category || "";
  $("color").value = item.color || "";
  $("material").value = item.material || "";
  $("warmth").value = item.warmth || "";
  $("status").value = item.status || "착용가능";
  $("notes").value = item.notes || "";
  $("userOverride").value = item.user_override ? "1" : "0";
  $("saveButton").textContent = "수정 저장";
  showExtraInfoForm(true);
  state.imageData = null;
  if (item.image_path) {
    $("preview").src = item.image_path;
    $("preview").hidden = false;
    $("photoActions").hidden = true;
    $("cameraActionButton").hidden = false;
  }
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function clothTitle(item) {
  return item.name || [item.color, item.sub_category || item.category].filter(Boolean).join(" ") || "이름 없는 옷";
}

function renderTags(item) {
  return [item.category, item.sub_category, item.color, item.material, item.warmth]
    .filter(Boolean)
    .map((tag) => `<span class="tag">${escapeHtml(tag)}</span>`)
    .join("");
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function renderClothes() {
  $("closetCount").textContent = `${state.clothes.length}개`;
  $("metricClothes").textContent = `${state.clothes.length}개`;
  if (state.clothes.length === 0) {
    $("closetGrid").innerHTML = `<p class="muted">아직 등록된 옷이 없습니다. 사진 촬영 또는 텍스트 입력으로 옷을 추가하세요.</p>`;
    return;
  }
  $("closetGrid").innerHTML = state.clothes
    .map((item) => {
      const image = item.image_path
        ? `<img src="${item.image_path}" alt="${escapeHtml(clothTitle(item))}">`
        : `<span>사진 없음</span>`;
      const isAvailable = (item.status || "착용가능") === "착용가능";
      const availabilityLabel = isAvailable ? "오늘 못입음" : "착용 가능";
      return `
        <article class="cloth-card">
          <div class="cloth-image">${image}</div>
          <div class="cloth-body">
            <h3 class="cloth-title">${escapeHtml(clothTitle(item))}</h3>
            <span class="status">${escapeHtml(item.status || "착용가능")}</span>
            <div class="tags">${renderTags(item)}</div>
            <p class="muted">${escapeHtml(item.notes || "")}</p>
            <div class="card-actions">
              <button class="secondary" data-action="wear" data-id="${item.cloth_id}">입음</button>
              <button class="ghost" data-action="toggle-status" data-id="${item.cloth_id}">${availabilityLabel}</button>
              <button class="ghost" data-action="edit" data-id="${item.cloth_id}">수정</button>
              <button class="danger" data-action="delete" data-id="${item.cloth_id}">삭제</button>
            </div>
          </div>
        </article>
      `;
    })
    .join("");
}

function renderHistory(items) {
  $("metricHistory").textContent = `${items.length}개`;
  if (!items.length) {
    $("historyList").innerHTML = `<p class="muted">착용 이력이 없습니다.</p>`;
    return;
  }
  $("historyList").innerHTML = items
    .map(
      (item) => `
        <div class="history-item">
          <span>${escapeHtml(item.wear_date)}</span>
          <strong>${escapeHtml(item.name || `${item.color || ""} ${item.sub_category || item.category}`)}</strong>
        </div>
      `,
    )
    .join("");
}

async function loadClothes() {
  const data = await api("/api/clothes");
  state.clothes = data.items;
  renderClothes();
}

async function loadHistory() {
  const data = await api("/api/history");
  renderHistory(data.items);
}

async function refreshAll() {
  await Promise.all([loadClothes(), loadHistory()]);
}

async function saveCloth(event) {
  event?.preventDefault();
  const id = $("clothId").value;
  const payload = payloadFromForm();
  setMessage(id ? "수정 중입니다." : "저장 중입니다.");
  try {
    if (id) {
      await api(`/api/clothes/${id}`, { method: "PUT", body: JSON.stringify(payload) });
      setMessage("수정했습니다.");
    } else {
      const item = await api("/api/clothes", { method: "POST", body: JSON.stringify(payload) });
      setMessage(item.background_removed ? "배경 제거 후 저장했습니다." : "저장했습니다. rembg가 없으면 원본 PNG로 저장됩니다.");
    }
    resetForm();
    await refreshAll();
  } catch (error) {
    setMessage(error.message, true);
  }
}

async function handleClosetAction(event) {
  const button = event.target.closest("button[data-action]");
  if (!button) {
    return;
  }
  const id = Number(button.dataset.id);
  const item = state.clothes.find((entry) => entry.cloth_id === id);
  if (!item) {
    return;
  }

  if (button.dataset.action === "edit") {
    fillForm(item);
  }

  if (button.dataset.action === "delete") {
    if (!confirm("이 옷을 삭제할까요? 관련 착용 이력도 함께 삭제됩니다.")) {
      return;
    }
    await api(`/api/clothes/${id}`, { method: "DELETE" });
    await refreshAll();
  }

  if (button.dataset.action === "toggle-status") {
    const nextStatus = (item.status || "착용가능") === "착용가능" ? "세탁중" : "착용가능";
    await api(`/api/clothes/${id}`, {
      method: "PUT",
      body: JSON.stringify({ status: nextStatus }),
    });
    await refreshAll();
    await getRecommendations();
  }

  if (button.dataset.action === "wear") {
    await api(`/api/clothes/${id}/wear`, {
      method: "POST",
      body: JSON.stringify({ wear_date: new Date().toISOString().slice(0, 10) }),
    });
    await loadHistory();
    await getRecommendations();
  }
}

async function fetchWeather() {
  const locationName = normalizeRegionName(state.user?.weather_location) || "설정된 지역";
  $("weatherState").textContent = `${locationName} 날씨 자동 조회 중`;
  const data = await api("/api/weather");
  if (!data.available) {
    $("weatherState").textContent = data.message;
    return;
  }
  state.currentTemp = data.feels_like ?? data.temp;
  $("manualTemp").value = state.currentTemp;
  const rainText = data.precipitation_probability != null ? `, 강수 ${data.precipitation_probability}%` : "";
  $("weatherState").textContent = `${data.location || locationName} ${data.condition}, 체감 ${state.currentTemp}도${rainText}`;
  $("metricWeather").textContent = `${state.currentTemp}도 · ${data.condition || "날씨"}${rainText}`;
}

async function getRecommendations() {
  const temp = Number($("manualTemp").value || state.currentTemp || 18);
  state.currentTemp = temp;
  const data = await api(`/api/recommendations?temp=${encodeURIComponent(temp)}`);
  const trendText = data.trend
    ? `${data.trend.style_tag} / ${data.trend.color_combination} / ${data.trend.recommended_temp}도`
    : "트렌드 데이터 없음";
  $("recommendationSummary").innerHTML = `
    <strong>${temp}도 기준 추천</strong><br>
    <span>최근 5일 착용 제외: ${data.excluded_recent_count}개</span><br>
    <span>참조 트렌드: ${escapeHtml(trendText)}</span>
  `;

  if (!data.items.length) {
    $("recommendations").innerHTML = `<p class="muted">${escapeHtml(data.message || "추천 결과가 없습니다.")}</p>`;
    return;
  }

  const renderRecommendedItem = (item) => {
      const image = item.image_path
        ? `<img src="${item.image_path}" alt="${escapeHtml(clothTitle(item))}">`
        : `<span>사진 없음</span>`;
      const reasons = (item.reasons || []).map((reason) => `<li>${escapeHtml(reason)}</li>`).join("");
      return `
        <article class="cloth-card">
          <div class="cloth-image">${image}</div>
          <div class="cloth-body">
            <h3 class="cloth-title">${escapeHtml(clothTitle(item))}</h3>
            <div class="tags">${renderTags(item)}</div>
            <p class="muted">추천 점수 ${item.score}</p>
            <ul class="muted">${reasons}</ul>
          </div>
        </article>
      `;
  };

  const outfits = data.outfits?.length ? data.outfits : [{ title: "1안", items: data.items, score: 0 }];
  $("recommendations").innerHTML = outfits
    .map(
      (outfit) => `
        <section class="outfit-option">
          <div class="outfit-head">
            <h3>${escapeHtml(outfit.title || "추천안")}</h3>
            <span class="muted">총점 ${outfit.score || 0}</span>
          </div>
          <div class="outfit-grid">
            ${(outfit.items || []).map(renderRecommendedItem).join("")}
          </div>
        </section>
      `,
    )
    .join("");
}

function bindEvents() {
  $("loginForm").addEventListener("submit", login);
  $("registerForm").addEventListener("submit", register);
  $("logoutButton").addEventListener("click", logout);
  $("cameraActionButton").addEventListener("click", handleCameraAction);
  $("mobilePhotoInput").addEventListener("change", (event) => {
    loadPhotoFile(event.target.files?.[0]);
    event.target.value = "";
  });
  $("usePhotoButton").addEventListener("click", usePhoto);
  $("discardPhotoButton").addEventListener("click", clearPhoto);
  $("showExtraInfoButton").addEventListener("click", () => showExtraInfoForm(true));
  $("quickSaveButton").addEventListener("click", () => {
    $("userOverride").value = "0";
    saveCloth();
  });
  $("clothForm").addEventListener("submit", saveCloth);
  $("cancelEditButton").addEventListener("click", resetForm);
  $("closetGrid").addEventListener("click", handleClosetAction);
  $("menuButton").addEventListener("click", openMenu);
  $("closeMenuButton").addEventListener("click", closeMenu);
  $("menuOverlay").addEventListener("click", closeMenu);
  document.querySelectorAll("[data-menu-target]").forEach((button) => {
    button.addEventListener("click", () => handleMenuTarget(button.dataset.menuTarget));
  });
  $("regionSearchButton").addEventListener("click", searchRegions);
  $("closeRegionButton").addEventListener("click", closeRegionModal);
  $("closePasswordButton").addEventListener("click", closePasswordModal);
  $("passwordForm").addEventListener("submit", submitPassword);
  $("closeChangePasswordButton").addEventListener("click", closeChangePasswordModal);
  $("changePasswordForm").addEventListener("submit", changePassword);
  $("forgotPasswordButton").addEventListener("click", openResetPasswordModal);
  $("closeResetPasswordButton").addEventListener("click", closeResetPasswordModal);
  $("requestResetCodeButton").addEventListener("click", requestResetCode);
  $("resetPasswordForm").addEventListener("submit", resetPassword);
  $("clearClosetButton").addEventListener("click", () => openPasswordModal("clear"));
  $("regionSearchInput").addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
      event.preventDefault();
      searchRegions();
    }
  });
  $("regionResults").addEventListener("click", (event) => {
    const button = event.target.closest("button[data-region-index]");
    if (button) {
      saveRegion(Number(button.dataset.regionIndex));
    }
  });
  $("refreshButton").addEventListener("click", refreshAll);
  $("weatherButton").addEventListener("click", async () => {
    try {
      await fetchWeather();
    } catch (error) {
      $("weatherState").textContent = error.message;
    }
  });
  $("recommendButton").addEventListener("click", getRecommendations);
}

function preventPullToRefresh() {
  let startY = 0;
  window.addEventListener(
    "touchstart",
    (event) => {
      startY = event.touches[0]?.clientY || 0;
    },
    { passive: true },
  );
  window.addEventListener(
    "touchmove",
    (event) => {
      const currentY = event.touches[0]?.clientY || 0;
      if (window.scrollY <= 0 && currentY > startY) {
        event.preventDefault();
      }
    },
    { passive: false },
  );
}

bindEvents();
preventPullToRefresh();
setupBackGuard();
window.addEventListener("popstate", handleBackButton);
document.addEventListener("visibilitychange", () => {
  if (!document.hidden && state.user) {
    checkSession().catch(() => showAuth());
  }
});
checkSession().catch((error) => {
  setAuthMessage(error.message, true);
  showAuth();
});
